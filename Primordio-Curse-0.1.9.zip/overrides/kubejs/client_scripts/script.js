// priority: 0

console.info('EnxSMP - Client Scripts - Lang');
console.info('Made by carmello - https://lucasmellof.com');


onEvent('client.generate_assets', event => {
	console.info('EnxSMP - Client Scripts - Lang - Generating Assets');
	let rename = (item, newName) => event.addLang(Item.of(item).item.getDescriptionId(), newName)
	rename('mob_catcher:diamond_mob_catcher', "Mob Catcher I")
	rename('mob_catcher:netherite_mob_catcher', "Mob Catcher II")
});