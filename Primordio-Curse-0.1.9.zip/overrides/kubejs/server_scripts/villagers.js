console.info('EnxSMP - Server Scripts - Villagers');
console.info('Made by carmello - https://lucasmellof.com');

onEvent("morejs.player.start_trading", (event) => { 
	if (event.merchant.getVillagerData().getProfession().getName() === "scribe") {
		event.forEachOffers((o, i) => {
			o.disabled = true;
		});
	}
 });