console.info('EnxSMP - Server Scripts - Loot');
console.info('Made by carmello - https://lucasmellof.com');

onEvent("lootjs", (event) => {
	console.log("LootJS event fired!");
	event.addLootTableModifier("iceandfire:chest/cyclops_cave").removeLoot("iceandfire:manuscript");
	event.addLootTableModifier("iceandfire:chest/ice_dragon_roost").removeLoot("iceandfire:manuscript");
	event.addLootTableModifier("iceandfire:chest/graveyard").removeLoot("iceandfire:manuscript");
	event.addLootTableModifier("iceandfire:chest/myrmex_trash_chest").removeLoot("iceandfire:manuscript");
	event.addLootTableModifier("iceandfire:chest/mausoleum_chest").removeLoot("iceandfire:manuscript");
	event.addLootTableModifier("iceandfire:chest/lightning_dragon_roost").removeLoot("iceandfire:manuscript");
	event.addLootTableModifier("iceandfire:chest/ice_dragon_male_cave").removeLoot("iceandfire:manuscript");
	event.addLootTableModifier("iceandfire:chest/fire_dragon_male_cave").removeLoot("iceandfire:manuscript");
	event.addLootTableModifier("iceandfire:chest/village_scribe").removeLoot("iceandfire:manuscript");
	event.addLootTableModifier("iceandfire:chest/lightning_dragon_male_cave").removeLoot("iceandfire:manuscript");
	event.addLootTableModifier("iceandfire:chest/myrmex_loot_chest").removeLoot("iceandfire:manuscript");
	event.addLootTableModifier("iceandfire:chest/hydra_cave").removeLoot("iceandfire:manuscript");
	event.addLootTableModifier("iceandfire:chest/fire_dragon_roost").removeLoot("iceandfire:manuscript");
	
});

// Hacky fix
onEvent('block.left_click', e => {
	let block = e.getBlock()
	if (block === "born_in_chaos_v1:infected_diamond_ore") {
		block.set("minecraft:diamond_ore")
	}
	if (block === "born_in_chaos_v1:infected_deepslate_diamond_ore") {
		block.set("minecraft:deepslate_diamond_ore")
	}
});