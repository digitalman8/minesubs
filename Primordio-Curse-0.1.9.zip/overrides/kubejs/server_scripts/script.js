// priority: 0

settings.logAddedRecipes = false
settings.logRemovedRecipes = true
settings.logSkippedRecipes = true
settings.logErroringRecipes = true

console.info('EnxSMP - Server Scripts - General');
console.info('Made by carmello - https://lucasmellof.com');

onEvent('recipes', event => {
	event.remove({
		output: "mob_catcher:diamond_mob_catcher"
	});
	event.shaped("mob_catcher:diamond_mob_catcher", [
		"ABA",
		"BCB",
		"ABA"
	], {
		'A': 'minecraft:flint',
		'B': '#forge:ingots/gold',
		'C': 'minecraft:lead'
	});

	event.remove({
		output: "mob_catcher:netherite_mob_catcher"
	});
	event.shaped("mob_catcher:netherite_mob_catcher", [
		"ABA",
		"BCB",
		"ABA"
	], {
		'A': '#forge:ingots/copper',
		'B': '#forge:ingots/iron',
		'C': 'minecraft:lead'
	});
})